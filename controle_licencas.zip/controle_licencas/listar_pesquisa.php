<?php
session_start();
include('verifica_login.php');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
    <link rel="stylesheet" href="css/bulma.min.css" />
    <link rel="stylesheet" type="text/css" href="css/login.css">
	<link rel="stylesheet" href="./style.css">	
	<link rel="stylesheet" href="./novo_menu.css">
</head>
<ul class="menu">
      <li title="home"><a href="#" class="menu-button home">menu</a></li>      	  
	  <li title="Voltar"><a href="init.php" class="volta">Voltar</a></li>  
	  <li title="Enviar e-mail"><a href="mailto:ti@lotisa.com.br" class="contact">Enviar e-mail</a></li>
    </ul>    
    <ul class="menu-bar">
        <li><a href="#" class="menu-button">Menu</a></li>
        <li><a href="listar_pesquisa.php">Home</a></li>		
        
    </ul>		
<!-- partial -->
<body>
 <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script><script  src="./novo_menu.js"></script>

<body>
<span id='topo'></span>

<?php
$usuario_cadastro = $_SESSION['usuario'];
print '<p>';
print 'Olá: ';
print $usuario_cadastro;
print '<p>';
print 'Seja Bem Vindo(a).';
print '<br>';
?> 
            
                    <h1 class="title has-text-grey">LISTAR LICENCAS</h1>
					<h2 class="title has-text-grey"><font size=4><center>[Tecnologia da Informação]</font></h2>                   
					
					<font size=2 color=gray>
	
	<ul>
	<font size=2 color=Blue>
	Legenda:
	<font size=2 color=gray>
	<li>(M) mensal</li>
	<li>(A) anual</li>
	<li>(T) trienal</li>
	<li>(P) perpetua</li></p>
</ul>
</font>
				</center><br><br><br>
                    <div class="box">
					<p align=left>					
				   <img src=css/logo.png><br></p>
				   <center>
					

					
					
					<form name="form1" action="listar_pesquisa.php" method="post">
<td>Pesquisar Por Nome?:
<br>
<input type="text"  name="colaborador_procura" class="campo"/></td></tr>
<tr>
<td></td>
<td><input type="submit" value="Pesquisar" /><input type="hidden" name="done"  value="" /></td>
</tr>
</tbody>
</table>
</form>

<form name="form1" action="listar_pesquisa_modalidade.php" method="post">
<td>Pesquisar Modalidade?:
<br>
<select name="colaborador_procura"   autofocus="" >									
									<option>SELECIONE</option>
  <?php 
   include "sql_t.i.php";//conexão com o banco de dados   
   @mysql_select_db($db);//selecione o banco de dados 
           $sqltudo = mysql_query(" select modalidade  from controle_licencas group by modalidade;")  or die(mysql_error());
           $colunas = mysql_num_rows($sqltudo);		
           for($j = 0; $j < $colunas; $j++){/*caso no mesmo dia tenha mais eventos continua imprimindo */                   		   
		   $modalidade = @mysql_result($sqltudo, $j, "modalidade");           
            print'<option>'; 						
            echo $modalidade;
            print '</option>';          
           }
		   ?>
		   </select>		
		   <tr>
<td></td>
<td><input type="submit" value="Pesquisar" /><input type="hidden" name="done"  value="" /></td>
</tr>
</tbody>
</table>
</form>	

<p align=right>

<label class="switch" onClick="window.location.href='exportData.php';">
  <input type="checkbox">
  <span class="slider round"></span>
</label>Download Grid .CSV
</p>

					
					<?php 
   include "sql_t.i.php";//conexão com o banco de dados   
   @mysql_select_db($db);//selecione o banco de dados
// SELECT NO BANCO PARA CRIAR A TABELA COM OS DADOS E IMPRIMIR NA TELA   
	$colaborador_retorno = $_POST['colaborador_procura'];
	$sqltudo = mysql_query("select  * FROM controle_licencas  where colaborador like UPPER('$colaborador_retorno%') and D_E_L_E_T_E IS NULL order by OBRA ")  or die(mysql_error());           
    $colunas = mysql_num_rows($sqltudo);	   
	
	
	   print'<br>';	
	   print'<br>';		   	
       print'<table border="1"   bordercolor="#00BFFF" >';
	   print'<tr>';	   
	   print'<td><b>ID</td>';	   
	   print'<td><b>D</td>';
	   print'<td><b>A</td>';	   
	   print'<td><b>HISTORICO</td>';  
	   print'<td><b>NOME</td>';	   
	   print'<td><b>DESCRICAO</td>';
	   print'<td><b>COLABORADOR</td>';
	   print'<td><b>OLD</td>';
	   print'<td><b>DEPARTAMENTO</td>';
	   print'<td><b>CUSTO</td>';
	   print'<td><b>FORNECEDOR</td>';
	   print'<td><b>CONTATO</td>';
	   print'<td><b>OBRA</td>';	   	   	   
	   print'<td><b>MODALIDADE</td>';  
	   print'<td><b>VALIDADE</td>';  
	   print'<td><b>NFE</td>';	   
	   
	   
	   print'</tr></b>';
           for($j = 0; $j < $colunas; $j++){/*caso no mesmo dia tenha mais eventos continua imprimindo */
           $id = @mysql_result($sqltudo, $j, "id");/*pegando os valores do banco referente ao evento*/
           $nome = @mysql_result($sqltudo, $j, "nome");
           $descricao = @mysql_result($sqltudo, $j, "descricao");
		   $valor = @mysql_result($sqltudo, $j, "valor");
           $fornecedor = @mysql_result($sqltudo, $j, "fornecedor");
           $contato = @mysql_result($sqltudo, $j, "contato");           		   
		   $obra = @mysql_result($sqltudo, $j, "obra");  
		   $modalidade = @mysql_result($sqltudo, $j, "modalidade");  		   
		   $url_nfe = @mysql_result($sqltudo, $j, "url_nfe");
		   $colaborador = @mysql_result($sqltudo, $j, "colaborador");
		   $departamento = @mysql_result($sqltudo, $j, "departamento");
		   $validade = @mysql_result($sqltudo, $j, "validade");
		   
		  
	   /*print '<table border=1>';/*monta a tabela de eventos*/

	       print'<tr>';	       
		   print '<td>'.$id.'</td>';	       
		   print '<td><a href="delete.php?id='.$id.'"><img src=images/bolinha_vermelha.png width=25 height=25></a></td>';  
		   print '<td><a href="listar_pesquisa_update.php?id='.$id.'"><img src=images/relogio.jpg width=25 height=25"></a></td>';	   	   		   
		   print '<td><a href="historico.php?id='.$id.'"><img src=images/historico.jpg width=40 height=40></a>';		   
	   // INCLUI O NUMERO DE HISTORICOS AO LADO DO ICONE DE HISTORICO
		   include "sql_t.i.php";//conexão com o banco de dados   
           @mysql_select_db($db);//selecione o banco de dados
           
		   $colaborador_old='';
		   $sqltudo2 = mysql_query("SELECT count(colaborador)as num_hist,colaborador,id_historico FROM controle_licencas_historico where id_historico = $id and D_E_L_E_T_E IS NULL order by id desc limit 1")  or die(mysql_error());
           $colunas2 = mysql_num_rows($sqltudo2);		  	   
           for($x = 0; $x < $colunas2; $x++){/*caso no mesmo dia tenha mais eventos continua imprimindo */           
           $id_historico = @mysql_result($sqltudo2, $x, "id_historico"); 		   
		   $num_historico = @mysql_result($sqltudo2, $x, "num_hist"); 
		   $colaborador_old = @mysql_result($sqltudo2, $x, "colaborador"); 
		   print $num_historico;	   	   		   		   
		   //print $id_historico;	   	   		   		   
	       print'</td>';	   
           }	   
		   //FIM DA INCLUSAO 
		if ($colaborador == 'LIVRE')  { 
		   print '<td bgcolor=#40E0D0>'.$nome.'</td>';	   
		   print '<td bgcolor=#40E0D0>'.$descricao.'</td>';
		   print '<td bgcolor=#40E0D0>'.$colaborador.'</td>';
		   print '<td bgcolor=#40E0D0>'.$colaborador_old.'</td>';
		   print '<td bgcolor=#40E0D0>'.$departamento.'</td>';
		   print '<td bgcolor=#40E0D0>'.$valor.'</td>';
		   print '<td bgcolor=#40E0D0>'.$fornecedor.'</td>';
		   print '<td bgcolor=#40E0D0>'.$contato.'</td>';
		   print '<td bgcolor=#40E0D0>'.$obra.'</td>';
		   if ($modalidade =='MENSAL'){
			print '<td bgcolor=#40E0D0>(M)</td>';
		   }
		   
		   if ($modalidade =='ANUAL'){
			print '<td bgcolor=#40E0D0>(A)</td>';
		   }
		   if ($modalidade =='TRIENAL'){
			print '<td bgcolor=#40E0D0>(T)</td>';
		   }
		   if ($modalidade =='PERPETUA'){
			print '<td bgcolor=#40E0D0>(P)</td>';
		   }

		   if ($modalidade ==''){
			print '<td bgcolor="orange">(V)</td>';
		   }

		   if ($modalidade =='MODALIDADE'){
			print '<td bgcolor="orange">(V)</td>';
		   }
	
	  
	   // CONTAGEM REGRESSIVA DOS DIAS QUE FALTAM
	   
	$hoje = date ('y-m-d');
    $data_inicio = new DateTime($hoje);
    $data_fim = new DateTime($validade);

    // Resgata diferença entre as datas
    $dateInterval = $data_inicio->diff($data_fim);   
	
if($modalidade!='PERPETUA'){

	if ($dateInterval->days <60){
		print '<td bgcolor=pink>'.$validade.' Faltam:'.$dateInterval->days.'</td>';
	}
	
	else{
		print '<td bgcolor=#40E0D0>'.$validade.' Faltam:'.$dateInterval->days.'</td>';
	}
}else{
	print '<td bgcolor=#40E0D0>---</td>';
}

	  
	   if ($url_nfe == ""){  
		       
		print ' <td><form method="post" action="file_upload_nfe.php?id='.$id.'" enctype="multipart/form-data">
					<label>Arquivo:</label>
					<input type="file" name="arquivo" />
					<input type="submit" value="Enviar" />
		     		</form></td>';
		
		
		//print '<td><a href="uploads_nfe/'.$url_nfe.'"target="_blank"><img src="images/bolinha_vermelha.png" width=30 height=30></a>';	
}else{	
	print '<td><a href="uploads_nfe/'.$url_nfe.'"target="_blank"><img src="images/bolinha_verde.png" width=30 height=30></a>';	
}
		
		}else{
			print '<td>'.$nome.'</td>';	   
			print '<td>'.$descricao.'</td>';
			print '<td>'.$colaborador.'</td>';
			print '<td>'.$colaborador_old.'</td>';
			print '<td>'.$departamento.'</td>';
			print '<td>'.$valor.'</td>';
			print '<td>'.$fornecedor.'</td>';
			print '<td>'.$contato.'</td>';
			print '<td>'.$obra.'</td>';
			if ($modalidade =='MENSAL'){
			 print '<td>(M)</td>';
			}
			
			if ($modalidade =='ANUAL'){
			 print '<td>(A)</td>';
			}
			if ($modalidade =='TRIENAL'){
			 print '<td>(T)</td>';
			}
			if ($modalidade =='PERPETUA'){
			 print '<td>(P)</td>';
			}
 
			if ($modalidade ==''){
			 print '<td bgcolor="orange">(V)</td>';
			}
 
			if ($modalidade =='MODALIDADE'){
			 print '<td bgcolor="orange">(V)</td>';
			}
	 
	   
		// CONTAGEM REGRESSIVA DOS DIAS QUE FALTAM
		
	 $hoje = date ('y-m-d');
	 $data_inicio = new DateTime($hoje);
	 $data_fim = new DateTime($validade);
 
	 // Resgata diferença entre as datas
	 $dateInterval = $data_inicio->diff($data_fim);   
	 
 if($modalidade!='PERPETUA'){
 
	 if ($dateInterval->days <60){
		 print '<td bgcolor=pink>'.$validade.' Faltam:'.$dateInterval->days.'</td>';
	 }
	 
	 else{
		 print '<td >'.$validade.' Faltam:'.$dateInterval->days.'</td>';
	 }
 }else{
	 print '<td >---</td>';
 }
 
	   
		if ($url_nfe == ""){  
				
		 print ' <td><form method="post" action="file_upload_nfe.php?id='.$id.'" enctype="multipart/form-data">
					 <label>Arquivo:</label>
					 <input type="file" name="arquivo" />
					 <input type="submit" value="Enviar" />
					  </form></td>';
		 
		 
		 //print '<td><a href="uploads_nfe/'.$url_nfe.'"target="_blank"><img src="images/bolinha_vermelha.png" width=30 height=30></a>';	
 }else{	
	 print '<td><a href="uploads_nfe/'.$url_nfe.'"target="_blank"><img src="images/bolinha_verde.png" width=30 height=30></a>';	
 }
		 
		}
print '</tr>';	

           }
	   print'</table>';
		
		
		
	   

?>


					</div>
                </div>
            </div>
        </div>
  
    </section>
	<a href='#topo'>Voltar ao topo</a>

</body>
</html>
