<?php
session_start();
include('verifica_login.php');
?>
<script language="javascript" type="text/javascript">

function maiuscula(z){
        v = z.value.toUpperCase();
        z.value = v;
    }	
</script>

<?php
$usuario_cadastro = $_SESSION['usuario'];
print '<p>';
print 'Olá: ';
print $usuario_cadastro;
print '<p>';
print 'Seja Bem Vindo(a).';
print '<br>';
?> 

<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
    <link rel="stylesheet" href="css/bulma.min.css" />
    <link rel="stylesheet" type="text/css" href="css/login.css">
	<link rel="stylesheet" href="./style.css">
	<link rel="stylesheet" href="./novo_menu.css">
</head>
<ul class="menu">
      <li title="home"><a href="#" class="menu-button home">menu</a></li>      
      <li title="Voltar"><a href="listar_pesquisa.php" class="volta">Voltar</a></li>  
	  <li title="Enviar e-mail"><a href="mailto:ti@lotisa.com.br" class="contact">Enviar e-mail</a></li>
    </ul>    
    <ul class="menu-bar">
        <li><a href="#" class="menu-button">Menu</a></li>
        <li><a href="listar.php">Home</a></li>		
       
    </ul>		
<!-- partial -->
<body>
 <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script><script  src="./novo_menu.js"></script>
<script language="javascript" type="text/javascript">

function maiuscula(z){
        v = z.value.toUpperCase();
        z.value = v;
    }	
</script>

<br>
<body> 
	


			<div class="column is-4 is-offset-4">
                    <h1 class="title has-text-grey">ATUALIZAÇÃO DE LICENCAS</h1><center>
					<h2 class="title has-text-grey"><font size=4>[Tecnologia da Informação]</font></h2> </center><br>
					
					<?php

//criar a conexÃ£o com o banco

include "sql_t.i.php";



if(isset($_POST['done'])){      
    $id_retorno = $_POST['id_retorno'];
    $sqltudo = mysql_query("select  * FROM controle_licencas  where id= $id_retorno")  or die(mysql_error());           
    $colunas = mysql_num_rows($sqltudo);	  
    for($j = 0; $j < $colunas; $j++){/*caso no mesmo dia tenha mais eventos continua imprimindo */
        $id = @mysql_result($sqltudo, $j, "id");/*pegando os valores do banco referente ao evento*/
        $nome = @mysql_result($sqltudo, $j, "nome");
        $descricao = @mysql_result($sqltudo, $j, "descricao");
        $valor = @mysql_result($sqltudo, $j, "valor");
        $fornecedor = @mysql_result($sqltudo, $j, "fornecedor");
        $contato = @mysql_result($sqltudo, $j, "contato");           		   
        $obra = @mysql_result($sqltudo, $j, "obra");  
        $modalidade = @mysql_result($sqltudo, $j, "modalidade");  		   
        $url_nfe = @mysql_result($sqltudo, $j, "url_nfe");
        $colaborador = @mysql_result($sqltudo, $j, "colaborador");
        $departamento = @mysql_result($sqltudo, $j, "departamento");
        $modalidade = @mysql_result($sqltudo, $j, "modalidade");
        $validade = @mysql_result($sqltudo, $j, "validade");
    }
    
    $sql2 = mysql_query("INSERT INTO `controle_licencas_historico`(`data_cadastro`,`valor`,`nome`, `descricao`, `fornecedor`, `contato`,`obra`,`usuario_cadastro`,`id_historico`,`modalidade`,`url_nfe`,`colaborador`,`departamento`,`validade`) VALUES (now(),'$valor','$nome','$descricao ', '$fornecedor', '$contato','$obra','$usuario_cadastro','$id_retorno','$modalidade','$url_nfe','$colaborador','$departamento','$validade')") or die(mysql_error());
    
    //INICIO DE UPDATE DOS CAMPOS
        
    $nome_retorno = $_POST['nome'];
    $descricao_retorno = $_POST['descricao'];
	$fornecedor_retorno = $_POST['fornecedor'];
    $contato_retorno = $_POST['contato'];
    $obra_retorno = $_POST['obra'];        
	$valor_retorno = $_POST['valor'];      
    $modalidade_retorno = $_POST['modalidade'];      
	$usuario_cadastro_retorno = $_SESSION['usuario'];    
    $url_nfe_retorno = $_POST['url_nfe'];
    $valor_retorno = $_POST['valor'];
    $colaborador_retorno = $_POST['colaborador'];
    $departamento_retorno = $_POST['departamento'];
    $validade_retorno = $_POST['validade'];

    


	$sql_update = mysql_query("update `controle_licencas` set nome='$nome_retorno',descricao ='$descricao_retorno',fornecedor='$fornecedor_retorno',contato='$contato_retorno',obra='$obra_retorno',valor='$valor_retorno',usuario_cadastro='$usuario_cadastro_retorno',modalidade='$modalidade_retorno',url_nfe='$url_nfe_retorno',colaborador='$colaborador_retorno',departamento='$departamento_retorno',validade='$validade_retorno' where id = '$id_retorno'") or die(mysql_error()); 		   
    
	   
            if($sql2){
                print '<script> alert("Historico Gravado  com sucesso!")</script>';
              } else{
                print '<script> alert("Não foi possivel cadastrar Histórico!!!")</script>';
              }

              if($sql_update){
                print '<script> alert("Atualização  Gravada  com sucesso!")</script>';
              } else{
                print '<script> alert("Não foi possivel Gravar Atualização!!!")</script>';
              }

    }

    

?>
					

                    <div class="box">


<font size=1>  
  <form name="form1" action="listar_pesquisa_update.php" method="POST">


<p align=left>
				   <img src=css/logo.png><br></p>

					
				<?php 
   include "sql_t.i.php";//conexão com o banco de dados   
   @mysql_select_db($db);//selecione o banco de dados
	$id_retorno = $_GET['id'];    
    if ($id_retorno ==''){    

    }else{  
    
	$sqltudo = mysql_query("select  * FROM controle_licencas  where id= $id_retorno ")  or die(mysql_error());           
    $colunas = mysql_num_rows($sqltudo);
           for($j = 0; $j < $colunas; $j++){/*caso no mesmo dia tenha mais eventos continua imprimindo */
            $id = @mysql_result($sqltudo, $j, "id");/*pegando os valores do banco referente ao evento*/
            $nome = @mysql_result($sqltudo, $j, "nome");
            $descricao = @mysql_result($sqltudo, $j, "descricao");
            $valor = @mysql_result($sqltudo, $j, "valor");
            $fornecedor = @mysql_result($sqltudo, $j, "fornecedor");
            $contato = @mysql_result($sqltudo, $j, "contato");           		   
            $obra = @mysql_result($sqltudo, $j, "obra");  
            $modalidade = @mysql_result($sqltudo, $j, "modalidade");  		   
            $url_nfe = @mysql_result($sqltudo, $j, "url_nfe");
            $colaborador = @mysql_result($sqltudo, $j, "colaborador");
            $departamento = @mysql_result($sqltudo, $j, "departamento");
            $modalidade = @mysql_result($sqltudo, $j, "modalidade");
            $validade = @mysql_result($sqltudo, $j, "validade");
		   
           }
    }
   
	   

?>

                               <div class="field">
                                <div class="control">                                    									
									
                                    <input type="text" placeholder="nome" name="nome"  value="<?php echo $nome; ?>" class="input is-large" onkeyup="maiuscula(this)"/>
									<input type="text" placeholder="descricao" name="descricao" value="<?php echo $descricao; ?>"class="input is-large" onkeyup="maiuscula(this)"/>									
									<input type="text" placeholder="colaborador" name="colaborador" value="<?php echo $colaborador; ?>" class="input is-large" onkeyup="maiuscula(this)"/>
                                    <input type="text" placeholder="departamento" name="departamento" value="<?php echo $departamento; ?>" class="input is-large" onkeyup="maiuscula(this)"/>
                                    <input type="text" placeholder="fornecedor" name="fornecedor" value="<?php echo $fornecedor; ?>" class="input is-large" onkeyup="maiuscula(this)"/>
                                    <input type="text" placeholder="contato" name="contato" value="<?php echo $contato; ?>" class="input is-large" onkeyup="maiuscula(this)"/>
                                    <input type="number" placeholder="valor" name="valor" value="<?php echo $valor; ?>" class="input is-large" onkeyup="maiuscula(this)"/>                                                                        									
									<?php 
										include "sql_t.i.php";//conexão com o banco de dados   
										@mysql_select_db($db);//selecione o banco de dados 
										$sqltudo = mysql_query(" select modalidade  from  controle_licencas where id='$id_retorno';")  or die(mysql_error());
										$colunas = mysql_num_rows($sqltudo);		
										for($j = 0; $j < $colunas; $j++){/*caso no mesmo dia tenha mais eventos continua imprimindo */                   										           
										$modalidade_FULL = @mysql_result($sqltudo, $j, "modalidade");										
										}
										
									?>
									
                                    <select name="modalidade" class="input is-large"   autofocus="" >									
                                    <option>MODALIDADE</option>
								        <option>MENSAL</option>									   
                                        <option>ANUAL</option>									   
                                        <option><?php echo $modalidade_FULL;?></option>									   
                                        <option>PERPETUA</option>	                                        						   
                                        <option value="<?php echo $modalidade_FULL;?>" selected><?php echo $modalidade_FULL;?></option>
										   </select>	

									
									
									<select name="obra"    autofocus="" class="input is-large">									
									<option>SELECIONE OBRA</option>
									<?php 
										include "sql_t.i.php";//conexão com o banco de dados   
										@mysql_select_db($db);//selecione o banco de dados 
										$sqltudo = mysql_query(" select nome from  crtl_patrimonio_obras;")  or die(mysql_error());
										$colunas = mysql_num_rows($sqltudo);		
										for($j = 0; $j < $colunas; $j++){/*caso no mesmo dia tenha mais eventos continua imprimindo */                   
										$id = @mysql_result($sqltudo, $j, "id");           
										$nome = @mysql_result($sqltudo, $j, "nome");
										print'<option>'; 						
										echo $nome;
										print '</option>';          
										}
										print '<option selected="selected">';
										echo $obra;
										print'</option>';   
									?>
									</select>                                    
                                    <input type="date" placeholder="validade" name="validade" value="<?php echo $validade; ?>" class="input is-large" onkeyup="maiuscula(this)"/>
                                    <input type="text" placeholder="url_contrato" name="url_nfe" value="<?php echo $url_nfe; ?>" class="input is-large" onkeyup="maiuscula(this)"/>
									
									<td><input type="hidden" enable="false" name="id_retorno" value="<?php echo $id_retorno; ?>" size=6/></td></tr>

									
									
										
									
																	
									
                                </div>
                            </div>
                            <?php
                            if ($id_retorno ==''){
                                print '<font size=4>';
                                print '<center>';
                                print '<a href=listar_pesquisa.php>VOLTAR</a>';
                            }else{
                            print '<button type="submit" onclick="" class="button is-block is-link is-large is-fullwidth">ATUALIZAR</button><input type="hidden" name="done"  value="" />';
                            }
                            ?>
                        </form>

						
						

						
                    </div>
                </div>
            </div>
        </div>
    </section>
	

</body>

</html>